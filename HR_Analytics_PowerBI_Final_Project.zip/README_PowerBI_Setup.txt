HUMAN RESOURCES ANALYTICS – POWER BI PROJECT

Purpose
Create an HR decision-support dashboard covering recruitment, turnover, employee satisfaction,
performance and hiring-needs forecasting.

FILES
1. HR_Analytics_PowerBI_Ready.xlsx – all tables + a preview dashboard.
2. Employees.csv – employee master data.
3. Recruitment.csv – recruitment funnel and hiring metrics.
4. Satisfaction.csv – satisfaction and engagement survey data.
5. Performance.csv – performance and goal-achievement data.
6. Hiring_Forecast.csv – historical hiring trend + Oct-Dec 2026 forecast rows.
7. HR_Analytics_PowerBI_Theme.json – optional Power BI theme.

RECOMMENDED POWER BI PAGES
Page 1 – HR Overview
KPI cards: Active Employees, Turnover Rate, Total Hires, Avg Time to Hire,
Avg Satisfaction, Avg Performance, Recruitment Cost.
Visuals: employees by department, turnover by department, hiring trend.

Page 2 – Recruitment Analytics
Funnel: Applicants > Screened > Interviewed > Offers > Hires.
Charts: hires by department, average time-to-hire by department, recruitment cost.
KPIs: offer-to-hire rate, applicant-to-hire rate, average time-to-hire.

Page 3 – Workforce & Turnover
Charts: headcount by department, turnover rate by department, exits by role/location.
Use Employee_ID as the unique employee key.

Page 4 – Satisfaction & Performance
Charts: satisfaction by department, performance by department, work-life balance,
manager rating, goal achievement, promotion readiness.
Use slicers for Department, Location, Role.

Page 5 – Hiring Forecast
Line chart: historical hires and forecast hires.
Forecast period included: Oct-Dec 2026.
Use the forecast values as planning estimates, not guaranteed hiring requirements.

KEY DAX MEASURES
Active Employees = CALCULATE(COUNTROWS(Employees), Employees[Employment_Status]="Active")
Exited Employees = CALCULATE(COUNTROWS(Employees), Employees[Employment_Status]="Exited")
Turnover Rate = DIVIDE([Exited Employees], COUNTROWS(Employees), 0)
Total Hires = SUM(Recruitment[Hires])
Avg Time to Hire = AVERAGE(Recruitment[Avg_Time_to_Hire_Days])
Avg Satisfaction = AVERAGE(Satisfaction[Satisfaction_Score])
Avg Performance = AVERAGE(Performance[Performance_Score])
Recruitment Cost = SUM(Recruitment[Recruitment_Cost_INR])
Offer to Hire Rate = DIVIDE(SUM(Recruitment[Hires]), SUM(Recruitment[Offers]), 0)
Applicant to Hire Rate = DIVIDE(SUM(Recruitment[Hires]), SUM(Recruitment[Applicants]), 0)

STAKEHOLDER FINDING TO HIGHLIGHT
The synthetic project data indicates that HR should monitor turnover together with satisfaction
and performance rather than looking at headcount alone. Department-level turnover varies,
while satisfaction and performance also differ across departments. This dashboard is designed
to identify departments that need closer review and to support hiring-capacity planning.

IMPORTANT
The dataset is synthetic and created for an analytics portfolio/task demonstration.
The Hiring Forecast is a simple planning estimate based on recent hiring levels; it should
not be presented as a production ML forecast without validating it against real company data.
